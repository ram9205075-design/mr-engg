const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true,
    default: 'New Product'
  },
  desc: {
    type: String,
    required: false,
    default: 'Product description'
  },
  price: {
    type: String,
    required: false,
    default: 'Contact for price'
  },
  images: [{
    type: String,
    required: false
  }],
  sku: {
    type: String,
    required: [true, 'SKU is required'],
    unique: true,
    trim: true
  },
  category: {
    type: String,
    required: false,
    default: 'General'
  },
  stock: {
    type: Number,
    required: false,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
