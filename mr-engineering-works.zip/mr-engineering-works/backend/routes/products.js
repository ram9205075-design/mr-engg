const express = require('express');
const router = express.Router();
const { uploadMultiple } = require('../middleware/upload');
const authMiddleware = require('../middleware/auth');
const {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  deleteProductImage
} = require('../controllers/productController');

// Public routes
router.get('/', getProducts);
router.get('/:id', getProduct);

// Protected routes (require authentication)
router.post('/', authMiddleware, uploadMultiple, createProduct);
router.put('/:id', authMiddleware, uploadMultiple, updateProduct);
router.delete('/:id', authMiddleware, deleteProduct);
router.delete('/:id/images/:imageIndex', authMiddleware, deleteProductImage);

module.exports = router;
