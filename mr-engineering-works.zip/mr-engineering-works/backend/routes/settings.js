const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const {
  getSettings,
  updateSetting,
  initSettings
} = require('../controllers/settingsController');

// Public routes
router.get('/', getSettings);

// Protected routes
router.put('/:type', authMiddleware, updateSetting);
router.post('/init', authMiddleware, initSettings);

module.exports = router;
