const Settings = require('../models/Settings');

// @desc    Get all settings
// @route   GET /api/settings
exports.getSettings = async (req, res) => {
  try {
    const settings = await Settings.find();
    
    // Convert to key-value object
    const settingsObject = {};
    settings.forEach(setting => {
      settingsObject[setting.type] = setting.content;
    });

    res.json({
      success: true,
      data: settingsObject
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update setting
// @route   PUT /api/settings/:type
exports.updateSetting = async (req, res) => {
  try {
    const { type } = req.params;
    const { content } = req.body;

    const setting = await Settings.findOneAndUpdate(
      { type },
      { content, updatedAt: Date.now() },
      { upsert: true, new: true }
    );

    res.json({
      success: true,
      message: `${type} updated successfully`,
      data: setting
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Initialize default settings
// @route   POST /api/settings/init
exports.initSettings = async (req, res) => {
  try {
    const defaultSettings = [
      {
        type: 'address',
        content: '123 Industrial Estate, Phase II, Pune - 411035, India'
      },
      {
        type: 'map',
        content: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783.229253187472!2d73.85625531478838!3d18.520430287404358!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c065144d8edf%3A0x37a9a4fcbaaa26d6!2sPune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1625123456789!5m2!1sen!2sin'
      },
      {
        type: 'about',
        content: 'MR Engineering Works is a premier tool manufacturing company based in Pune, India. With over 25 years of experience, we specialize in custom tooling, industrial fabrication, and precision engineering.'
      },
      {
        type: 'privacy',
        content: 'We respect your privacy. All data collected is used solely for communication and order processing. We do not share your information with third parties.'
      },
      {
        type: 'disclaimer',
        content: 'Information provided on this website is for general purposes only. MR Engineering Works assumes no liability for any errors or omissions. Product images are for representation only.'
      }
    ];

    for (const setting of defaultSettings) {
      await Settings.findOneAndUpdate(
        { type: setting.type },
        setting,
        { upsert: true }
      );
    }

    res.json({
      success: true,
      message: 'Default settings initialized'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
